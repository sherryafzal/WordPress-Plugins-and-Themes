

<?php 



echo "This is a test-output";

	//$plugins_url = plugins_url();



//include 'search.php';

?>




	 
	
	 
	 
	
	
	
	
	