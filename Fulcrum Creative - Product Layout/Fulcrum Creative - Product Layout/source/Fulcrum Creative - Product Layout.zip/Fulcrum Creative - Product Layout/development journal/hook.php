<?php 


add_action( 'wp_head', 'Product Images - Fulcrum Creative.' );

?>