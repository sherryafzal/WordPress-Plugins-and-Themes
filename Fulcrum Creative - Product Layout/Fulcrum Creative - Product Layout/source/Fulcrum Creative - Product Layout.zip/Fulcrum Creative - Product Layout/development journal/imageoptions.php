<?php 


$optionchoice = $_POST['optionselect'];
  if($optionchoice = 'option1')
  {
    echo("opton 1 was selected....");
  }
  
  
   if($optionchoice = 'option2')
  {
    echo("opton 2 was selected....");
  }
   if($optionchoice = 'option3
   ')
  {
    echo("opton 3 was selected....");
  }
  ?>
    