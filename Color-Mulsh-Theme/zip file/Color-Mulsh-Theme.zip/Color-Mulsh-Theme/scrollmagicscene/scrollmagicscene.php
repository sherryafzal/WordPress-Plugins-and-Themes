<?php 


?>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>



<link href="./css/style.css" rel="stylesheet" type="text/css">


<head>
<script type="text/javascript"  src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.20.3/TweenMax.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/ScrollMagic.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/plugins/debug.addIndicators.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/plugins/animation.gsap.min.js"></script>


<script src="./js/fadeins.js"></script>

<link href="./css/scrollmagic.css" rel="stylesheet" type="text/css">

<!--




<script src="./js/scrollmagic/minified/ScrollMagic.min.js"></script>




<script src="./js/scrollmagic/lib/greensock/TweenMax.min.js"></script>




<script src="./js/scrollmagic/lib/greensock/jquery.gsap.min.js"></script>



<script src="./js/scrollmagic/minified/plugins/animation.velocity.min.js"></script>
<script src="./js/scrollmagic/minified/plugins/debug.addIndicators.min.js"></script>




-->

<div id = "#trigger"> THIS IS THE TRIGGER
</div>

<div id="anim_1">
<div class="introduction">CODE KICKS ASS. version 1.</div>




</div>







<div id="Space_filler">







</div>



<div id = "anim_1_end">
</div>


<div class = "box_1"><img src = "./images/box_story_1.png">
</div>
<div id="box_1_in">
</div>

<div id="Space_filler">

</div>

