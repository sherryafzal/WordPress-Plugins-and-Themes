<?php
/**
*  This is a theme by Fulcrum Creative.com. A lot of work has gone into making this theme happen,
*  so please respect it, and be patient because updates are garaunteed for this theme.
*  if there's something not satisfactory about this theme, do not hesitate to contact us via email.
*  you can email us at 
*                                     support@fulcrum-creative.com
* 786
*
 * Learn more about our company at http://www.fulcrum-creative.com
 *
 * @package WordPress
 * @subpackage Color_Mulsh
 * @version 0.9 Beta
 */

?>

<link href="<?php bloginfo('template_url');?>/css/style.css" rel="stylesheet" type="text/css">



<?php


?><!DOCTYPE html>


<title><?php wp_title(); ?></title>

<html>
<head>
  <!-- title and meta -->
  <meta charset="utf-8">
  
 
 </head>
 <body>


   
  
    


</body>



</html>

