<html>
<br>
<br>
<br>
<div style="margin-left: 0px; text-align: center;">
<b>Welcome to Fulcrum Creative's<br> <br>Ajax Live Search Plugin.<br>
<p>
WE BUILD YOUR WORLD.<br>
</p>
<p>
For More information, visit Our Website : <br>
</p>
<p>
<a href="http://www.fulcrum-creative.com/" target="_blank">www.fulcrum-creative.com</a>
</p>
<p>
For Plugin Support, Please do not hesitate to email : <br>
</p>
<p>
<a href="mailto:support@fulcrum-creative.com">support@fulcrum-creative.com</a>
</p>
</b>
</div>

<b></b>

<div style="float: right; position: relative; margin-left: 150px; text-align: center; width: 75%; height: 75%;">
</div>
</html>
<?php
echo '<a href= "http://www.fulcrum-creative.com" target="_blank"><img src="' . plugins_url ( 'graphics/logo.png', __FILE__ ) . '" style="height:100px; width:200px; float:left;"></style>';
?>