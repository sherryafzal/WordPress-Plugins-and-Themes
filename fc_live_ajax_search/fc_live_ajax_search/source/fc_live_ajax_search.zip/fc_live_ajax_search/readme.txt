known issues.

- the shortcode won't work in two locations at the same time.
- the plugin displays on top of page, regardless of position of shortcode on the page.
- unknown characters generated during plugin activation.





6.13.2017

- uploaded plugin.
- 